#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/pstat.h"

struct pstat pinfo;

int main(int argc, char *argv[]) {
    getpinfo(&pinfo);
    int q = 0;

    if(pinfo.inuse[q] > 0) {
        
        for(int a =0; a < NPROC; a++) {
            printf("%d\n", pinfo.ticks[a]);
            printf("%d\n", pinfo.tickets[a]);
        }
    }
}