Input:

hardwork 10&
hardwork 20&
hardwork 30&

getpinfo

Output: 

$ getpinfo

26
1
22
1
5
1
207
10
141
20
94
30
0
0
0...
